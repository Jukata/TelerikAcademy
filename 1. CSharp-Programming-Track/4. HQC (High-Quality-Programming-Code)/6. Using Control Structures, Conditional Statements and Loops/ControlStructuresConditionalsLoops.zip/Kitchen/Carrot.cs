﻿namespace Kitchen
{
    public class Carrot : Vegetable
    {
    }
}
