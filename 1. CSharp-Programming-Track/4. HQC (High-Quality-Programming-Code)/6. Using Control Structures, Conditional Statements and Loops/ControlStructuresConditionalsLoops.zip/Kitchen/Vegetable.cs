﻿namespace Kitchen
{
    public class Vegetable
    {
    }
}
