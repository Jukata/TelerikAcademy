﻿namespace MathOperationsPerformanceForDiffTypes
{
    public class AddMethods
    {
        public static int Add(int firstNumber, int secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public static long Add(long firstNumber, long secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public static float Add(float firstNumber, float secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public static double Add(double firstNumber, double secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public static decimal Add(decimal firstNumber, decimal secondNumber)
        {
            return firstNumber + secondNumber;
        }
    }
}
