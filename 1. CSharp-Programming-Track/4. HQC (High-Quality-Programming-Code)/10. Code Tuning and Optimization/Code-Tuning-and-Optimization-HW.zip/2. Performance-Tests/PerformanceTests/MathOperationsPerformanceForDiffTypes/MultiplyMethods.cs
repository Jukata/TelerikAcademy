﻿namespace MathOperationsPerformanceForDiffTypes
{
    public class MultiplyMethods
    {
        public static int Multiply(int firstNumber, int secondNumber)
        {
            return firstNumber * secondNumber;
        }

        public static long Multiply(long firstNumber, long secondNumber)
        {
            return firstNumber * secondNumber;
        }

        public static float Multiply(float firstNumber, float secondNumber)
        {
            return firstNumber * secondNumber;
        }

        public static double Multiply(double firstNumber, double secondNumber)
        {
            return firstNumber * secondNumber;
        }

        public static decimal Multiply(decimal firstNumber, decimal secondNumber)
        {
            return firstNumber * secondNumber;
        }
    }
}
