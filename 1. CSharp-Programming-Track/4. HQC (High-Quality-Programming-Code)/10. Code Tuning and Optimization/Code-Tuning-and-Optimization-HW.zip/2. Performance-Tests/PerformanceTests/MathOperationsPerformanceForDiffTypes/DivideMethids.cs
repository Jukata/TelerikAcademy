﻿namespace MathOperationsPerformanceForDiffTypes
{
    public class DivideMethods
    {
        public static int Divide(int firstNumber, int secondNumber)
        {
            return firstNumber / secondNumber;
        }

        public static long Divide(long firstNumber, long secondNumber)
        {
            return firstNumber / secondNumber;
        }

        public static float Divide(float firstNumber, float secondNumber)
        {
            return firstNumber / secondNumber;
        }

        public static double Divide(double firstNumber, double secondNumber)
        {
            return firstNumber / secondNumber;
        }

        public static decimal Divide(decimal firstNumber, decimal secondNumber)
        {
            return firstNumber / secondNumber;
        }
    }
}
