﻿namespace MathOperationsPerformanceForDiffTypes
{
    public class SubtractMethods
    {
        public static int Subtract(int firstNumber, int secondNumber)
        {
            return firstNumber - secondNumber;
        }

        public static long Subtract(long firstNumber, long secondNumber)
        {
            return firstNumber - secondNumber;
        }

        public static float Subtract(float firstNumber, float secondNumber)
        {
            return firstNumber - secondNumber;
        }

        public static double Subtract(double firstNumber, double secondNumber)
        {
            return firstNumber - secondNumber;
        }

        public static decimal Subtract(decimal firstNumber, decimal secondNumber)
        {
            return firstNumber - secondNumber;
        }
    }
}
