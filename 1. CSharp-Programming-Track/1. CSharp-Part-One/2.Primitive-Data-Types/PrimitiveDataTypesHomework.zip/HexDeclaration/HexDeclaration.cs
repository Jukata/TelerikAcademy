﻿using System;
//Declare an integer variable and assign it with the value 254 in hexadecimal
//format. Use Windows Calculator to find its hexadecimal representation.


class HexDeclaration
{
    static void Main()
    {
        int intInHex = 0xFE;
        Console.WriteLine(intInHex);
    }
}

