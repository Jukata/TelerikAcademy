﻿using System;
//Which of the following values can be assigned to a variable of type float
//and which to a variable of type double: 34.567839023, 12.345, 8923.1234857, 3456.091?


class AppropriateFloatVariable
{
    static void Main()
    {
        double firstFloatVariable = 34.567839023;
        float secondFloatVariable = 12.345F;
        double thirdFloatVariable = 8923.1234857;
        float forthFloatVariable = 3456.091F;
        Console.WriteLine(firstFloatVariable);
        Console.WriteLine(secondFloatVariable);
        Console.WriteLine(thirdFloatVariable);
        Console.WriteLine(forthFloatVariable);


    }
}

