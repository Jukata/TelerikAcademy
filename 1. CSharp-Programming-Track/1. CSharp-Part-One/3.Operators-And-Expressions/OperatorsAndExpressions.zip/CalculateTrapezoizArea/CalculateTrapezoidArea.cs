﻿using System;
//Write an expression that calculates trapezoid's area by given sides a and b and height h.
//S = (a + b) / 2 * h.
class CalculateTrapezoidArea
{
    static void Main()
    {
        Console.Write("a=");
        double a = double.Parse(Console.ReadLine());
        Console.Write("b=");
        double b = double.Parse(Console.ReadLine());
        Console.Write("h=");
        double h = double.Parse(Console.ReadLine());
        double area = ((a + b) / 2) * h;
        Console.WriteLine("The area of trapezoid with sides a={0}, b={1} , h={2} is {3}", a, b, h, area);
    }
}

