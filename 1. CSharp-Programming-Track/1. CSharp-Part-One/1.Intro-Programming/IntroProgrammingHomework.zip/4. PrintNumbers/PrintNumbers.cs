﻿using System;

class PrintNumbers
{
    static void Main()
    {
        Console.WriteLine(1);
        Console.WriteLine(101);
        Console.WriteLine(1001);
    }
}

