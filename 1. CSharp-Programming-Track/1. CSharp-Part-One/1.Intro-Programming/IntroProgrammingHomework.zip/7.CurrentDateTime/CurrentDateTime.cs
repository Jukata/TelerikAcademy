﻿using System;

class CurrentDateTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}
