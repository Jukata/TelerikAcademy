﻿using System;

class MembersOfSequence
{
    static void Main()
    {
        for (int i = 2; i < 12; i++)
        {
            Console.WriteLine(i);
            i++;
            Console.WriteLine(-i);
        }
    }
}

