﻿using System;


class Program
{
    static void Main()
    {
        Console.WriteLine(12345*12345);
    }
}

