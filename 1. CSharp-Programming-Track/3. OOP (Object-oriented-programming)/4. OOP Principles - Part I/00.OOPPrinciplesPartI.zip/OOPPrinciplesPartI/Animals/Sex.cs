﻿public enum Sex
{
    male,
    female,
    other
}