﻿namespace Student
{
    public enum University
    {
        SofiaUniversity,
        TechnicalUniversiy,
        NewBulgarianUniversity,
    }
}
