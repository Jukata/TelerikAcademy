﻿namespace Student
{
    public enum Faculty
    {
        FMI,
        FKSU,
        Math,
        FTK,
        MTF
    }
}
