﻿namespace Student
{
    public enum Speciality
    {
        ComputerSystem,
        InformationTechnologies,
        Telecommunication,
        MTT
    }
}
