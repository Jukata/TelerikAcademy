﻿/// <reference path="jquery-2.0.2.js" />

var UIComponents = (function () {
    
})();